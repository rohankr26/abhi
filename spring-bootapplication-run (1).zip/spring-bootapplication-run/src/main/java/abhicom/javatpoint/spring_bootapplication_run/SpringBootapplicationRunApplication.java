package abhicom.javatpoint.spring_bootapplication_run;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootapplicationRunApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootapplicationRunApplication.class, args);
	}

}
