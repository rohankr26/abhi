package abhicom.javatpoint.spring_bootapplication_run;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootapplicationRunApplicationTests {

	@Test
	void contextLoads() {
	}

}
